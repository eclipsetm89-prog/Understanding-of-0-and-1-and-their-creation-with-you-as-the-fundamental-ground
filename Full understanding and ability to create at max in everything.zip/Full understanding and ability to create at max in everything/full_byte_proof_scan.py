#!/usr/bin/env python3
"""
Full 0-255 byte proof scan.

The original package only ever tested powers of 2 (8,16,32,64,128,256,512)
against 4 fixed operators, and those 4 operators were tautological by
construction (they always equal the value no matter what, so FINAL was
always OK -- it wasn't actually testing anything).

This script tests EVERY value 0-255 against REAL, non-tautological proofs:

  DOUBLE  (/) : v is evenly divisible by 2        -> v/2 is a whole number
  HALVES  (+) : v can be split into two EQUAL whole halves (a+a=v, a!=0)
  FACTOR  (x) : v has a non-trivial factor pair a*b=v with 1<a<v (v is composite)
  DIFF    (-) : v can be written as a difference of two DISTINCT smaller
                positive values that are NOT just v and 0 (i.e. v = a-b,
                a>b>0, b!=0, a<2v) -- in practice this is the interesting
                one because it's the only one that's true for almost
                everything, so it shows which test is "too easy" vs
                which is actually selective.

These are real constraints that some bytes pass and some fail -- unlike
the original table where every operator was guaranteed to succeed by
algebraic construction.
"""
import csv

def double_proof(v):
    if v == 0:
        return False, "0/2 not meaningful"
    ok = (v % 2 == 0)
    return ok, f"{v}/2={v//2}" if ok else f"{v}/2={v/2} (not whole)"

def halves_proof(v):
    if v % 2 != 0 or v == 0:
        return False, f"{v} has no equal whole-number halves"
    a = v // 2
    return True, f"{a}+{a}={v}"

def factor_proof(v):
    if v < 4:
        return False, f"{v} too small to factor"
    for a in range(2, int(v**0.5)+1):
        if v % a == 0:
            b = v // a
            return True, f"{a}x{b}={v}"
    return False, f"{v} is prime or 1 (no factor pair)"

def diff_proof(v):
    # genuinely fails only for v=0 and v=1 (can't pick a>b>0 with a-b=v and a<2v meaningfully for v=1: 2-1=1 actually works)
    if v == 0:
        return False, "0 has no positive difference pair"
    a = v + 1
    b = 1
    return True, f"{a}-{b}={v}"

rows = []
for v in range(256):
    d_ok, d_txt = double_proof(v)
    h_ok, h_txt = halves_proof(v)
    f_ok, f_txt = factor_proof(v)
    s_ok, s_txt = diff_proof(v)
    n_pass = sum([d_ok, h_ok, f_ok, s_ok])
    rows.append({
        'VALUE': v,
        'DOUBLE_/': 'OK' if d_ok else 'FAIL', 'DOUBLE_DETAIL': d_txt,
        'HALVES_+': 'OK' if h_ok else 'FAIL', 'HALVES_DETAIL': h_txt,
        'FACTOR_x': 'OK' if f_ok else 'FAIL', 'FACTOR_DETAIL': f_txt,
        'DIFF_-': 'OK' if s_ok else 'FAIL', 'DIFF_DETAIL': s_txt,
        'OPS_PASSING': n_pass,
    })

with open('/home/claude/byte_proof_full/full_0_255_proof_scan.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)

# Summary stats
from collections import Counter
dist = Counter(r['OPS_PASSING'] for r in rows)
print("Distribution of how many of the 4 operators pass, per value (0-255):")
for k in sorted(dist):
    print(f"  {k}/4 operators pass: {dist[k]} values")

print()
print("Values where ALL 4 operators FAIL (none work):")
none_pass = [r['VALUE'] for r in rows if r['OPS_PASSING']==0]
print(" ", none_pass)

print()
print("Values where ONLY 1 operator passes (hardest bytes to encode):")
one_pass = [(r['VALUE'], [k for k in ['DOUBLE_/','HALVES_+','FACTOR_x','DIFF_-'] if r[k]=='OK']) for r in rows if r['OPS_PASSING']==1]
for v, ops in one_pass[:20]:
    print(f"   {v}: only {ops}")
print(f"  ... total {len(one_pass)} values with only 1 operator passing")

print()
print("Values where ALL 4 operators pass:")
all_pass = [r['VALUE'] for r in rows if r['OPS_PASSING']==4]
print(f"  count: {len(all_pass)}  e.g. {all_pass[:20]}")
